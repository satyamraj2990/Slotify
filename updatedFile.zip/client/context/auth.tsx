import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type Role = "admin" | "teacher" | "student";
export type User = { username: string; role: Role } | null;

const STORAGE_KEY = "nep-ai-auth";

interface AuthContextProps {
  user: User;
  login: (args: { username: string; password: string; role: Role; remember?: boolean }) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch {}
  }, []);

  const login: AuthContextProps["login"] = useCallback(async ({ username, password, role, remember }) => {
    // Simple role-based credentials (demo): admin123 / teacher123 / student123
    const expected = role === "admin" ? "admin123" : role === "teacher" ? "teacher123" : "student123";
    if (!username || !password) return { ok: false, error: "Username and password required" };
    if (password !== expected) return { ok: false, error: "Invalid credentials" };
    const u: User = { username, role };
    setUser(u);
    if (remember) localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
    return { ok: true };
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const value = useMemo(() => ({ user, login, logout }), [user, login, logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
